head_pos = int(input('Enter Head Position: '))
look = list(map(int,input('Enter Req Array: ').split()))
look.sort()
for c in range(len(look)):
    if look[c]>head_pos:
        mid = c
        break
l1 = look[:mid]
l2 = look[mid:]
print(mid)
l1.reverse()
dis = (l2[-1]-head_pos) + (l2[-1] - l1[0])
print(dis)
print(f'Tracs order { l2 + l1}')