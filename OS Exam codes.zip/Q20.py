size = int(input('Enter no of tracks: '))
head_pos = int(input('Enter Head Position: '))
scan = list(map(int,input('Enter Req Array: ').split()))
dire = int(input('Enter Direction 1 for left 0 for right: '))
head1 = []
dis =0
#print(scan)
scan.sort()
for s in range(len(scan)):
    if scan[s] > head_pos:
        mid = s
        break
if dire == 1:
    l1 = scan[:mid]
    l2 = scan[mid:]
    #print(l1)
    l1.reverse()
    l1.append(0)
    #print(l2)
    dis = head_pos + l2[-1]
    l3 = l1+l2
    print(f'The Tracs are : {l3}')
    print(dis)
else:
    l1 = scan[:mid]
    l2 = scan[mid:]
    l1.reverse()
    l2.append(199)
    l3 = l2 + l1
    dis = head_pos + (199-head_pos) + (199-l1[-1])
    print(f'The tracs are {l3}')
    print(dis)
