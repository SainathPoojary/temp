# Function to perform C-LOOK on the request
# array starting from the given head
def CLOOK(x, head):
	
	seek_count = 0
	distance = 0
	cur_track = 0

	left = []
	right = []

	seek_sequence = []

	# Tracks on the left of the
	# head will be serviced when
	# once the head comes back
	# to the beginning (left end)
	for i in range(N):
		if (x[i] < head):
			left.append(x[i])
		if (x[i] > head):
			right.append(x[i])

	# Sorting left and right vectors
	left.sort()
	right.sort()

	# First service the requests
	# on the right side of the
	# head
	for i in range(len(right)):
		cur_track = right[i]
		
		# Appending current track
		# seek sequence
		seek_sequence.append(cur_track)

		# Calculate absolute distance
		distance = abs(cur_track - head)

		# Increase the total count
		seek_count += distance

		# Accessed track is now new head
		head = cur_track

	# Once reached the right end
	# jump to the last track that
	# is needed to be serviced in
	# left direction
	seek_count += abs(head - left[0])
	head = left[0]

	# Now service the requests again
	# which are left
	for i in range(len(left)):
		cur_track = left[i]

		# Appending current track to
		# seek sequence
		seek_sequence.append(cur_track)

		# Calculate absolute distance
		distance = abs(cur_track - head)

		# Increase the total count
		seek_count += distance

		# Accessed track is now the new head
		head = cur_track

	print("Total number of seek operations =",
		seek_count)
	print("Seek Sequence is")

	for i in range(len(seek_sequence)):
		print(seek_sequence[i])

# Driver code

n = []
 
# number of elements as input
N = int(input("Enter number of elements: "))
disk_size = int(input("Enter disk size: "))
 
# iterating till the range
print("Enter the elements one by one:\n")
for i in range(0, N):
    x = int(input())
 
    n.append(x) # adding the element
     
print('the processes are: ', n)
head = int(input("Initial position of head:"))
CLOOK(n, head)
