ref_string = list(map(int,input("Enter Refernce String numbers :").split()))
frames = int(input("Enter number of frames :")) 
page = 0
frame_status = [] 
count = 0
for i in ref_string:
    if i in frame_status: 
        continue
    if len(frame_status) == frames: 
        page+=1 
        frame_status[count] = i 
        count+=1
        if count == frames: 
            count=0
    else:
        frame_status.append(i)
    print(f'Frame Status : {frame_status}')
hit=len(ref_string)- page-frames
miss = page+frames
print(f'Page Fault is {miss}') 
print(f'Page Miss is {miss}')
print(f'Page Hit is {hit}')
print("Page Hit Ratio: "+str((hit/len(ref_string)*100)))
print("Page Miss Ratio: "+str((miss/len(ref_string)*100)))