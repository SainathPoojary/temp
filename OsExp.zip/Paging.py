import math
process = int(input("Size of process : "))
page_size = int(input("Size of page : "))
memory_size = int(input("Size of memory : "))
total_frames = memory_size*1024*1024 / page_size
total_frames = math.log(total_frames,2)
entries_page_table = process*1024/page_size
physical_memory = memory_size*1024*1024
def calc(n):
    expo = 0
    while(n%2 == 0):
        n/=2
        expo+=1
    return expo
phy = calc(physical_memory)
logical_bits = calc(process*1024)
offset = calc(page_size)
print(f'Total Number of bits in memory are: {phy}')
print(f'Page Table Entries: {entries_page_table}')
print(f'Total frames in memory: {total_frames}')
print(f'No of bits in logical address: {logical_bits}')
print(f'Total frames in memory: {total_frames}')
print(f'Offset Bits: {offset}')
page_ent = int(entries_page_table)
page_no = []
frame_no = []
valid1 = []
for i in range(page_ent):
    page_tab = int(input('Page no: '))
    frame_tab = int(input('Frame no (-1 for empty): '))
    if frame_tab != -1:
        valid = 1
        frame_no.append(frame_tab)
    else:
        valid = 0
        frame_no.append('...')
    page_no.append(page_tab)
    valid1.append(valid)
for i in range(1):
    print("Page no \t Frame no \t valid")
    for j in range(page_ent):
        print(f'{ page_no[j]} \t \t {frame_no[j]} \t \t {valid1[j]}')
for i in range(int(input('no. address to be checked: '))):
    c = []
    add = list(map(int, input('Enter address: ').split()))
    add1 = list(map(int, input('Enter offset: ').split()))
    add.reverse()
    sum = 0
    n=0
    for i in add:
        sum+=pow(2,n)*i
        n+=1
    for i in range(page_ent):
        if sum == page_no[i]:
            if valid1[i] == 1:
                print('Page Hit')
                c.append('1')
                break
    if not c:
        print('Page Miss')