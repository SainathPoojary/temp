# Python program to demonstrate
# FCFS Disk Scheduling algorithm


def FCFS(arr, head):

	seek_count = 0
	distance, cur_track = 0, 0

	for i in range(size):
		cur_track = arr[i];

		# calculate absolute distance
		distance = abs(cur_track - head);

		# increase the total count
		seek_count += distance;

		# accessed track is now new head
		head = cur_track;
	
	print("Total number of seek operations = ",
								seek_count);

	# Seek sequence would be the same
	# as request array sequence
	print("Seek Sequence is");

	for i in range(size):
		print(arr[i]);
	
# Driver code
if __name__ == '__main__':
	#size = 8
	## request array
	#arr = [ 176, 79, 34, 60,
	#		92, 11, 41, 114 ];
	#head = 50;
	arr = []
	size = int(input("Enter number of elements: "))
 
	# iterating till the range
	print("Enter the elements one by one:\n")
	for i in range(0, size):
		arr.append(int(input())) # adding the element
     
	print('the processes are: ', arr)
	head = int(input("Initial position of head:"))

	FCFS(arr, head)