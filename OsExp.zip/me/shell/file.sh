
for i in a*
do
    echo $i;
    cat $i
    echo
done