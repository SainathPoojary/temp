# !/bash/sh

isValid(){
	if [[ $1 == "admin" && $2 == "pass" ]]; 
	then
		retval="true";
	else
		retval="false";
	fi
	echo "$retval";
}

read -p "Enter username: " uname;
read -p "Enter password: " pass;

result=$(isValid $uname $pass);

echo $result;

if [[ result == "true" ]];
then
	echo "Login Successful";
else
	echo "Login Unsuccessful";
fi

