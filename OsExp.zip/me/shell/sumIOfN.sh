#!/bin/sh
read -p "How many no you want to add: " no;

sum=0;

for ((i = 1 ; i <= $no ; i++)); do
    read -p "Enter num $i: " num;
    sum=$(( $sum + $num));
done

echo $sum