#!/bin/sh
read -p "Enter num1: " a;
read -p "Enter num2: " b

echo "Addition is $(($a + $b))"
