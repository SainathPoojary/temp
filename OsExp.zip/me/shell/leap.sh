# !/bin/sh

read -p "Enter year: " year;


if [ $(($year % 4)) == 0 ]
then 
    echo "Leap year";
else
    echo "Not a leap year";
fi

