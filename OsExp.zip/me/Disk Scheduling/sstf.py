

def sortest(sequence, num):
    temp = abs(sequence[0] - num)
    value = sequence[0]

    for i in sequence:
        if (temp > abs(i-num)):
            temp = abs(i-num)
            value = i

    return value


head = int(input("Enter initial head position: "))
no = int(input("Enter no of sequence: "))

sequence = [head]

for i in range(no):
    pos = int(input(f"Enter pos {i+1}: "))
    sequence.append(pos)


# Creating new sequence
sSequence = [head]
num = head
for i in range(len(sequence)-1):
    sequence.remove(num)
    num = sortest(sequence, num)
    sSequence.append(num)

print(sSequence)

movement = 0

for i in range(no):
    movement += abs(sSequence[i]-sSequence[i+1])

print("head movement:", movement)
