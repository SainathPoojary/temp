

head = int(input("Enter initial head position: "))
no = int(input("Enter no of sequence: "))

sequence = [head]

for i in range(no):
    pos = int(input(f"Enter pos {i+1}: "))
    sequence.append(pos)


movement = 0

for i in range(no):
    movement += abs(sequence[i]-sequence[i+1])


print("head movement:", movement)
