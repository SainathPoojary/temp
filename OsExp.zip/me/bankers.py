import numpy

alloc = [[0, 1, 0], [2, 0, 0],
         [3, 0, 2], [2, 1, 1], [0, 0, 2]]

maximum = [[7, 5, 3], [3, 2, 2],
           [9, 0, 2], [2, 2, 2], [4, 3, 3]]

avail = [3, 3, 2]


# finding need matrix
need = list(numpy.subtract(maximum, alloc))
sequence = []
visited = [False]*len(maximum)

# Bankers's algo
for j in range(len(maximum)):
    for i in range(len(maximum)):
        if(not visited[i]):
            if(all(numpy.less_equal(need[i], avail))):
                avail = numpy.add(avail, alloc[i])
                sequence.append(i)
                visited[i] = True

if(all(visited)):
    print("Safe Sequence is ", end="")
    for i in sequence:
        print(f"P{i} => ", end="")

    print("|")
else:
    print("Not a safe sequence")
