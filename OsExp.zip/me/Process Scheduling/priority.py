import random
no = int(input("Enter no of processes: "))

processes = dict()

for i in range(no):
    priority = int(input(f"Enter priority for P{i+1}: "))
    burstTime = int(input(f"Enter burst time for P{i+1}: "))
    if priority in processes:
        priority += random.uniform(0.0001, 0.1000)
    processes[priority] = burstTime
    print()

# Sorting according to priority and creating gantt chart
gantt = list()
currTime = 0
gantt.append(currTime)
for i in sorted(processes.keys()):
    currTime += processes[i]
    gantt.append(currTime)

print("Gantt chart", gantt)


# For Waiting time
wt = 0
for i in range(gantt.__len__()-1):
    wt += gantt[i]

print("Waiting time:", (wt/no))

# For Turn Around time
tot = 0
for i in range(gantt.__len__()):
    tot += gantt[i]

print("Turn Around time:", (tot/no))