
import re


no = int(input("Enter no of processes: "))

processes = list()

for i in range(no):
    burstTime = int(input(f"Enter burst time for P{i+1}: "))
    processes.append(burstTime)

quantum = int(input("Enter quantum: "))

wt = [0]*no
tt = [0]*no
rembt = [0]*no
currTime = 0

for i in range(no):
    rembt[i] = processes[i]
while (True):
    done = True
    for i in range(no):
        if(rembt[i] > 0):
            done = False
            if(rembt[i] > quantum):
                currTime += quantum
                rembt[i] -= quantum
            else:
                currTime += rembt[i]
                wt[i] = currTime - processes[i]
                rembt[i] = 0
    if done:
        break

print(wt)

# Finding turnaround time

for i in range(no):
    tt[i] = wt[i] + processes[i]

print(tt)

print("AVERGAge wait time:", (sum(wt)/no))
print("Turnauround  time:", (sum(tt)/no))
