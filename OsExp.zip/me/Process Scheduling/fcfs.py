no = int(input("Enter no of processes: "))
currTime = 0
gantt = list()
gantt.append(currTime)
for i in range(no):
    burstTime = int(input(f"Enter burst time for P{i+1}: "))
    currTime += burstTime
    gantt.append(currTime)


# For Waiting time
wt = 0
print("Waiting time: ", end="")
for i in range(gantt.__len__()-1):
    print(gantt[i], end="")
    wt += gantt[i]
    if(i == gantt.__len__()-2):
        continue
    print(" + ", end="")

print(" =", (wt/no))

# For Turn Around time
tot = 0
for i in range(gantt.__len__()):
    tot += gantt[i]

print("Turn Around time:", (tot/no))
