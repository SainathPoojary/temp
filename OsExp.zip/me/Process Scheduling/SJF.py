no = int(input("Enter no of processes: "))

processes = list()

for i in range(no):
    burstTime = int(input(f"Enter burst time for P{i+1}: "))
    processes.append(burstTime)

processes.sort()

# Creating gantt chart
currTime = 0
gantt = list()
gantt.append(currTime)
for i in processes:
    currTime += i
    gantt.append(currTime)

print("Gantt chart:", gantt)


# For Waiting time
wt = 0
for i in range(gantt.__len__()-1):
    wt += gantt[i]

print("Waiting time:", (wt/no))

# For Turn Around time
tot = 0
for i in range(gantt.__len__()):
    tot += gantt[i]

print("Turn Around time:", (tot/no))
